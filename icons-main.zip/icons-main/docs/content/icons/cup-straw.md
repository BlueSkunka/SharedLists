---
title: Cup straw
categories:
  - Real world
tags:
  - mug
  - glass
  - drink
---
